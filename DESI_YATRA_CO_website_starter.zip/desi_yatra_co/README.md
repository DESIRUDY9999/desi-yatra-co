# DESI YATRA CO. — Free website starter

A responsive, static multi-page travel company website inspired by modern travel-agency layouts. It is an original starter design, not a copy of another company's branding or content.

## Included pages
- `index.html` — homepage
- `tours.html` — tour categories with working category filters
- `about.html` — company story and values
- `journal.html` — travel journal placeholder ideas
- `contact.html` — enquiry form and WhatsApp/email handoff
- `assets/style.css` — responsive visual design
- `assets/script.js` — menu, filters and enquiry actions
- `assets/config.js` — your contact details

## Before publishing
1. Open `assets/config.js`.
2. Add your official WhatsApp number in international format with digits only, e.g. `919876543210`.
3. Add your business email and Instagram URL.
4. Replace sample destination content with real packages, inclusions, exclusions, dates and prices.
5. Replace placeholder article ideas and verify every claim.
6. Add your legal business details, privacy policy, cancellation/refund terms and booking terms.
7. Use only photos you own, have licensed, or are permitted to use. Current demo images load from Unsplash and require internet access.

Example configuration:
```js
window.DESI_CONFIG = {
  whatsapp: "919876543210",
  email: "your-real-business-email@example.com",
  instagram: "https://www.instagram.com/yourhandle/"
};
```
Do not use the example email above as your real contact address.

## Publish free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com/.
2. Create a new public repository, e.g. `desi-yatra-co`.
3. Upload all files and folders from this ZIP (keep the folder structure).
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. GitHub will provide a public `github.io` website address after deployment.

Alternative: Netlify Drop at https://app.netlify.com/drop — unzip the folder and drag the `desi_yatra_co` folder into the upload area. Check current free-plan terms before relying on a hosting provider.

## Important limitations
- No booking engine, payment gateway, customer database, admin dashboard or live inventory is included.
- Enquiry form hands off to WhatsApp or email; it does not securely store enquiries.
- Sample tour categories are illustrative only. No prices, departures, availability or supplier relationships are represented as confirmed.
- This is a front-end starter, not a substitute for legal, tax, travel-operator or consumer-protection compliance.
