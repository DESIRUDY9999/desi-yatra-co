// Add your real business contact details before publishing.
// WhatsApp number format: country code + number, digits only. Example: 919876543210
window.DESI_CONFIG = {
  whatsapp: "",
  email: "",
  instagram: ""
};
